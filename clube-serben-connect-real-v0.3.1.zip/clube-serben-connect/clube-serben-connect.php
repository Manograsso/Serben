<?php
/**
 * Plugin Name: Clube Serben Connect
 * Description: Integração WordPress com a API Clube Serben.
 * Version: 0.3.1
 * Author: Pedro Manograsso
 * Requires PHP: 7.4
 * Text Domain: clube-serben-connect
 */

if (!defined('ABSPATH')) { exit; }

define('SERBEN_CONNECT_VERSION', '0.3.1');
define('SERBEN_CONNECT_FILE', __FILE__);
define('SERBEN_CONNECT_PATH', plugin_dir_path(__FILE__));
define('SERBEN_CONNECT_URL', plugin_dir_url(__FILE__));

require_once SERBEN_CONNECT_PATH . 'autoload.php';

register_activation_hook(__FILE__, ['SerbenConnect\\Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['SerbenConnect\\Plugin', 'deactivate']);

add_action('plugins_loaded', function () {
    SerbenConnect\Plugin::instance()->boot();
});
