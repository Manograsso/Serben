<?php
namespace SerbenConnect\Shortcodes;

if (!defined('ABSPATH')) { exit; }

class AppShortcode
{
    public function register(): void
    {
        add_shortcode('serben_app', [$this, 'render']);
    }

    public function render(): string
    {
        wp_enqueue_style('serben-connect');
        $lookup = (new LookupShortcode())->render();
        $register = (new RegisterShortcode())->render();
        return '<div class="serben-app"><h2>Área do Associado</h2><p>Consulte o CPF do associado ou realize um novo cadastro integrado à API Serben.</p>' . $lookup . '<hr>' . $register . '</div>';
    }
}
