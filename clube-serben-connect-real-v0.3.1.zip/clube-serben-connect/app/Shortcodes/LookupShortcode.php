<?php
namespace SerbenConnect\Shortcodes;

use SerbenConnect\Services\ClientesService;

if (!defined('ABSPATH')) { exit; }

class LookupShortcode
{
    public function register(): void
    {
        add_shortcode('serben_lookup', [$this, 'render']);
    }

    public function render(): string
    {
        wp_enqueue_style('serben-connect');
        $html = '<div class="serben-box"><h3>Consultar cadastro</h3>';
        $cpf = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['serben_lookup_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['serben_lookup_nonce'])), 'serben_lookup')) {
            $cpf = preg_replace('/\D+/', '', wp_unslash($_POST['serben_cpf'] ?? ''));
            $result = (new ClientesService())->buscarCompletoPorCpf($cpf);
            $html .= $this->resultHtml($result);
        }

        $html .= '<form method="post" class="serben-form">';
        $html .= wp_nonce_field('serben_lookup', 'serben_lookup_nonce', true, false);
        $html .= '<label>CPF <input type="text" name="serben_cpf" value="' . esc_attr($cpf) . '" required></label>';
        $html .= '<button type="submit">Consultar</button>';
        $html .= '</form></div>';

        return $html;
    }

    public function resultHtml(array $result): string
    {
        $portador = $result['portador'] ?? [];
        $cliente = $result['cliente'] ?? [];
        $principal = $result['principal'] ?? [];

        if (empty($portador['ok']) && empty($cliente['ok'])) {
            return '<div class="serben-alert serben-error"><strong>Falha na consulta.</strong><br>Portador HTTP ' . esc_html((string)($portador['code'] ?? 0)) . ' | Cliente HTTP ' . esc_html((string)($cliente['code'] ?? 0)) . '</div>' . $this->debugHtml($result);
        }

        $html = '<div class="serben-alert serben-success"><strong>Consulta realizada.</strong> Portador HTTP ' . esc_html((string)($portador['code'] ?? 0)) . ' | Cliente HTTP ' . esc_html((string)($cliente['code'] ?? 0)) . '</div>';

        $portadores = $this->extractPortadores($portador['body'] ?? null);
        if (!empty($portadores)) {
            foreach ($portadores as $p) {
                $html .= $this->portadorCard($p);
            }
        } else {
            $clientes = $this->extractClientes($cliente['body'] ?? null);
            if (!empty($clientes)) {
                foreach ($clientes as $c) {
                    $html .= $this->clienteCard($c);
                }
            } else {
                $html .= '<div class="serben-alert">A API respondeu com sucesso, mas o plugin não encontrou os dados no formato esperado. Veja a resposta técnica abaixo.</div>';
            }
        }

        $html .= $this->debugHtml($result);
        return $html;
    }

    private function extractPortadores($body): array
    {
        if (!is_array($body)) {
            return [];
        }
        $paths = [
            ['data', 'dados_portador'],
            ['dados_portador'],
            ['data'],
        ];
        foreach ($paths as $path) {
            $value = $body;
            foreach ($path as $key) {
                if (!is_array($value) || !array_key_exists($key, $value)) {
                    $value = null;
                    break;
                }
                $value = $value[$key];
            }
            if (is_array($value) && !empty($value)) {
                return $this->normalizeList($value);
            }
        }
        return [];
    }

    private function extractClientes($body): array
    {
        if (!is_array($body)) {
            return [];
        }
        $paths = [
            ['data', 'clientes'],
            ['data', 'cliente'],
            ['data'],
            ['clientes'],
            ['cliente'],
        ];
        foreach ($paths as $path) {
            $value = $body;
            foreach ($path as $key) {
                if (!is_array($value) || !array_key_exists($key, $value)) {
                    $value = null;
                    break;
                }
                $value = $value[$key];
            }
            if (is_array($value) && !empty($value)) {
                return $this->normalizeList($value);
            }
        }
        return [];
    }

    private function normalizeList(array $value): array
    {
        if ($this->isAssoc($value)) {
            return [$value];
        }
        return $value;
    }

    private function isAssoc(array $array): bool
    {
        return array_keys($array) !== range(0, count($array) - 1);
    }

    private function portadorCard(array $p): string
    {
        $html = '<div class="serben-card">';
        $html .= '<h4>' . esc_html($p['nome_portador'] ?? $p['nome'] ?? $p['nome_cliente'] ?? 'Portador') . '</h4>';
        $html .= '<p><strong>CPF:</strong> ' . esc_html($p['cpf_portador'] ?? $p['cpf'] ?? $p['cpf_cnpj'] ?? '') . '</p>';
        $html .= '<p><strong>E-mail:</strong> ' . esc_html($p['email_portador'] ?? $p['email'] ?? '') . '</p>';
        $html .= '<p><strong>Celular:</strong> ' . esc_html($p['celular_portador'] ?? $p['celular'] ?? $p['telefone'] ?? '') . '</p>';
        $html .= '<p><strong>Cartão:</strong> ' . esc_html($p['numero_cartao'] ?? '') . '</p>';
        $html .= '<p><strong>Loja:</strong> ' . esc_html($p['nome_loja'] ?? '') . '</p>';

        $contratos = $p['contratos_portador']['registros'] ?? [];
        if (is_array($contratos) && !empty($contratos)) {
            $html .= '<h5>Contratos</h5><ul>';
            foreach ($contratos as $c) {
                $html .= '<li>' . esc_html(($c['nome_plano'] ?? 'Plano') . ' — ' . ($c['situacao_contrato'] ?? '') . ' — ' . ($c['situacao_pagamento'] ?? '')) . '</li>';
            }
            $html .= '</ul>';
        }
        $html .= '</div>';
        return $html;
    }

    private function clienteCard(array $c): string
    {
        $html = '<div class="serben-card">';
        $html .= '<h4>' . esc_html($c['nome'] ?? $c['nome_cliente'] ?? $c['nome_portador'] ?? 'Cliente') . '</h4>';
        $html .= '<p><strong>CPF/CNPJ:</strong> ' . esc_html($c['cpf_cnpj'] ?? $c['documento'] ?? $c['cpf'] ?? $c['cpf_portador'] ?? '') . '</p>';
        $html .= '<p><strong>E-mail:</strong> ' . esc_html($c['email'] ?? $c['email_portador'] ?? '') . '</p>';
        $html .= '<p><strong>Celular:</strong> ' . esc_html($c['celular'] ?? $c['fone'] ?? $c['telefone'] ?? $c['celular_portador'] ?? '') . '</p>';
        if (!empty($c['cidade']) || !empty($c['estado'])) {
            $html .= '<p><strong>Cidade/UF:</strong> ' . esc_html(trim(($c['cidade'] ?? '') . '/' . ($c['estado'] ?? ''), '/')) . '</p>';
        }
        $html .= '</div>';
        return $html;
    }

    private function debugHtml(array $result): string
    {
        return '<details class="serben-debug"><summary>Resposta técnica da API</summary><pre>' . esc_html(print_r($result, true)) . '</pre></details>';
    }
}
