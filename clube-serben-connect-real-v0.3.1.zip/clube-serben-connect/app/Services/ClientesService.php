<?php
namespace SerbenConnect\Services;

use SerbenConnect\API\Client;
use SerbenConnect\Support\Settings;

if (!defined('ABSPATH')) { exit; }

class ClientesService
{
    private Client $client;

    public function __construct()
    {
        $this->client = new Client();
    }

    public function buscarPorDocumento(string $cpf): array
    {
        $cpf = preg_replace('/\D+/', '', $cpf);
        return $this->client->get('Clientes/byDocumento', ['documento' => $cpf], true);
    }

    public function buscarPortadorClube(string $cpf): array
    {
        $cpf = preg_replace('/\D+/', '', $cpf);
        // Conforme exemplo da Collection, Portador_clube usa apenas x-api-key.
        return $this->client->get('Portador_clube', ['pesquisa_portador' => $cpf], false);
    }

    public function buscarCompletoPorCpf(string $cpf): array
    {
        $cpf = preg_replace('/\D+/', '', $cpf);

        $portador = $this->buscarPortadorClube($cpf);
        $cliente = $this->buscarPorDocumento($cpf);

        return [
            'ok' => !empty($portador['ok']) || !empty($cliente['ok']),
            'cpf' => $cpf,
            'portador' => $portador,
            'cliente' => $cliente,
            'principal' => $this->temDadosPortador($portador) ? $portador : $cliente,
        ];
    }

    public function temDadosPortador(array $result): bool
    {
        $body = $result['body'] ?? [];
        return is_array($body) && !empty($body['data']['dados_portador']) && is_array($body['data']['dados_portador']);
    }

    public function cadastrar(array $data): array
    {
        $settings = Settings::all();
        $payload = [
            'cpf_cnpj' => $this->onlyDigits($data['cpf_cnpj'] ?? ''),
            'nome' => sanitize_text_field($data['nome'] ?? ''),
            'rg' => sanitize_text_field($data['rg'] ?? ''),
            'sexo' => sanitize_text_field($data['sexo'] ?? ''),
            'data_nasc' => sanitize_text_field($data['data_nasc'] ?? ''),
            'fone' => $this->onlyDigits($data['fone'] ?? ''),
            'celular' => $this->onlyDigits($data['celular'] ?? ''),
            'email' => sanitize_email($data['email'] ?? ''),
            'estado' => sanitize_text_field($data['estado'] ?? ''),
            'cidade' => sanitize_text_field($data['cidade'] ?? ''),
            'bairro' => sanitize_text_field($data['bairro'] ?? ''),
            'cep' => $this->onlyDigits($data['cep'] ?? ''),
            'endereco' => sanitize_text_field($data['endereco'] ?? ''),
            'numero' => sanitize_text_field($data['numero'] ?? ''),
            'complemento' => sanitize_text_field($data['complemento'] ?? ''),
            'cnpj_empresa' => $this->onlyDigits($settings['cnpj_empresa'] ?? ''),
            'codigo' => sanitize_text_field($settings['codigo'] ?? '1'),
        ];

        if (!empty($data['cnpj_corporacao'])) {
            $payload['cnpj_corporacao'] = $this->onlyDigits($data['cnpj_corporacao']);
        }

        return $this->client->post('Clientes', $payload, true);
    }

    private function onlyDigits(string $value): string
    {
        return preg_replace('/\D+/', '', $value);
    }
}
