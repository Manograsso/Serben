Clube Serben Connect v0.3.1

Correção de consulta CPF: tenta Portador_clube e Clientes/byDocumento, com parser flexível.
